/// <reference types="../CTAutocomplete" />
/// <reference lib="es2015" />

const GL11 = Java.type("org.lwjgl.opengl.GL11");

let imageRegex = /!\[.*?\]\((.*?)\)/g
let urlRegex = /\[(.*?)\]\(.*?\)/g
let basicUrlRegex = /(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)(?:\([-A-Z0-9+&@#\/%=~_|$?!:,.]*\)|[-A-Z0-9+&@#\/%=~_|$?!:,.])*(?:\([-A-Z0-9+&@#\/%=~_|$?!:,.]*\)|[A-Z0-9+&@#\/%=~_|$])/igm

let imagesCache = {}

function getImageFromCache(url){
    let urlId =url.replace(/[^A-z]/g,"")
    if(imagesCache[urlId] === undefined){
        imagesCache[urlId] = "LOADING"
        new Thread(()=>{
            try{
                imagesCache[urlId] = new Image("mm_" + urlId,url)
            }catch(e){
                imagesCache[urlId] = new Image("mm_" + url.replace("https://","http://").replace(/[^A-z]/g,""),url.replace("https://","http://"))
            }
        }).start()
        return undefined
    }
    if(imagesCache[urlId] === "LOADING"){
        return undefined
    }
    return imagesCache[urlId]
}

class RenderLibs {
    constructor(){
        this.lastSizzorX = 0
        this.lastSizzorY = 0
        this.lastSizzorW = 0
        this.lastSizzorH = 0
        this.scizzoring = false
    }

    drawString = function(text, x, y, scale){
        Renderer.scale(scale, scale)
        Renderer.drawString(text || "undefined", x/scale, y/scale)
        Renderer.scale(1, 1)
    }
    drawStringCentered = function(text, x, y, scale){
        this.drawString(text, x-((Renderer.getStringWidth(ChatLib.removeFormatting(text))/2)*scale), y-((9*scale)/2),scale)
    }
    drawStringCenteredVertically = function(text, x, y, scale){
        this.drawString(text, x, y-((7*scale)/2),scale)
    }
    drawStringCenteredFull = function(text, x, y, scale){
        this.drawStringCentered(text, x, y-((7*scale)/2),scale)
    }
    drawStringResiseWidth = function(text, x, y, scale, maxWidth){
        let scale2 = Math.max(1,Renderer.getStringWidth(ChatLib.removeFormatting(text))/(maxWidth/scale))
        this.drawString(text, x, y, scale/scale2)
    }
    getCurrScizzor = function(){
        return [this.lastSizzorX,this.lastSizzorY,this.lastSizzorW,this.lastSizzorH]
    }
    scizzor = function(x, y, width, height){
        if(this.scizzoring){
            if(this.lastSizzorW === 0 || this.lastSizzorH === 0) return;
            let intersect = getIntersectingRectangle({x1:this.lastSizzorX,y1:this.lastSizzorY,x2:this.lastSizzorX+this.lastSizzorW,y2:this.lastSizzorY+this.lastSizzorH},{x1:x,y1:y,x2:x+width,y2:y+height})
            if(intersect === false){
                this.lastSizzorW = 0
                this.lastSizzorH = 0
                GL11.glScissor(0,0,0,0)
                GL11.glDisable(GL11.GL_SCISSOR_TEST);
                return;
            }else{
                x = intersect.x1
                y = intersect.y1
                width = Math.min(width, this.lastSizzorW,intersect.x2-intersect.x1)
                height= Math.min(height,this.lastSizzorH,intersect.y2-intersect.y1)
            }
        }
        this.lastSizzorX = x
        this.lastSizzorY = y
        this.lastSizzorW = width
        this.lastSizzorH = height
        let guiScale = Renderer.screen.getScale()
        let screenHeight = Renderer.screen.getHeight()
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        try{
            GL11.glScissor(x*guiScale, screenHeight*guiScale-(y*guiScale)-(height*guiScale), width*guiScale, height*guiScale)
        }catch(e){
            this.lastSizzorW = 0
            this.lastSizzorH = 0
            GL11.glScissor(0,0,0,0)
            GL11.glDisable(GL11.GL_SCISSOR_TEST);
            return;
        }
        this.scizzoring = true
    }
    stopScizzor = function(){
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
        this.scizzoring = false
    }
    drawBox = function(color,x,y,w,h,borderWidth){
        let colorR = color[0]
        let colorG = color[1]
        let colorB = color[2]
        Renderer.drawRect(Renderer.color(colorR, colorG, colorB),x+borderWidth,y+borderWidth,w-borderWidth*2,h-borderWidth*2)
        Renderer.drawRect(Renderer.color(colorR-20*(color[3]?-1:1), colorG-20*(color[3]?-1:1), colorB-20*(color[3]?-1:1)),x,y,borderWidth,h)
        Renderer.drawRect(Renderer.color(colorR-20*(color[3]?-1:1), colorG-20*(color[3]?-1:1), colorB-20*(color[3]?-1:1)),x,y,w,borderWidth)
        Renderer.drawRect(Renderer.color(colorR-60*(color[3]?-1:1), colorG-60*(color[3]?-1:1), colorB-60*(color[3]?-1:1)),x+w-borderWidth,y,borderWidth,h)
        Renderer.drawRect(Renderer.color(colorR-60*(color[3]?-1:1), colorG-60*(color[3]?-1:1), colorB-60*(color[3]?-1:1)),x,y+h-borderWidth,w,borderWidth)
    }
    renderTextBlockWithMarkup = function(textArr, x, y, width){
        let yOff = 0
        let isCodeBlock=false
        let imageClickData = []
        textArr.split("\n").forEach((line)=>{
            if(line.startsWith("# ")){
                yOff += this._renderSmallTextWithMarkup(line.substr(2),x, y+yOff,2,width)
                return;
            }
            if(line.startsWith("## ")){
                yOff += this._renderSmallTextWithMarkup(line.substr(3),x, y+yOff,1+1.5/2,width)
                return;
            }
            if(line.startsWith("### ")){
                yOff += this._renderSmallTextWithMarkup(line.substr(4),x, y+yOff,1.5,width)
                return;
            }
            if(line.startsWith("#### ")){
                yOff += this._renderSmallTextWithMarkup(line.substr(5),x, y+yOff,1.325,width)
                return;
            }
            if(line.startsWith("##### ")){
                yOff += this._renderSmallTextWithMarkup(line.substr(6),x, y+yOff,1.25,width)
                return;
            }
            if(line.startsWith("###### ")){
                yOff += this._renderSmallTextWithMarkup(line.substr(7),x, y+yOff,1.125,width)
                return;
            }
            if(line.startsWith("```")){
                isCodeBlock = !isCodeBlock
                if(!isCodeBlock){
                    Renderer.drawRect(Renderer.color(0,0,0,50),x,y+yOff,width, 2)
                    yOff+=2
                }
                yOff += 3
                return;
            }else{
                if(isCodeBlock){
                    this.splitStringAtWidth(line.replace(/&/g,"&⭍"),width-4).forEach((line2)=>{
                        Renderer.drawRect(Renderer.color(0,0,0,50),x,y+yOff,width, 10)
                        this.drawString("&8" + line2,x+2,y+yOff+2,1)
                        yOff += 10
                    })
                    return;
                }
            }

            let first = true
            let image = undefined

            line.split("!").forEach((section)=>{
                if(first){
                    first = false
                    return;
                }

                let result = imageRegex.exec("!" + section)
                imageRegex.lastIndex = 0

                if(result !== null){
                    image = getImageFromCache(result[1])
                }
            })

            if(!(line !== "" && line.replace(/!\[.*?\]\(.*?\)/g,"") == "")){
                yOff += this._renderSmallTextWithMarkup(line.replace(/!\[.*?\]\(.*?\)/g,""),x, y+yOff,1,width)
            }

            if(image !== undefined && image !== null){
                try{
                    
                    let imageScale = Infinity

                    imageScale = Math.min(imageScale,(width-4)/image.getTextureWidth())
                    imageScale = Math.min(imageScale,300/image.getTextureHeight())
                    
                    image.draw(x, y+yOff,image.getTextureWidth()*imageScale,image.getTextureHeight()*imageScale)
                    imageClickData.push([x, y+yOff,image.getTextureWidth()*imageScale,image.getTextureHeight()*imageScale,image])
                    
                    yOff += image.getTextureHeight()*imageScale

                }catch(e){
                    //idk!
                }
            }
        }) 

        return {height:yOff,imageClickData: imageClickData}
    }
    _renderSmallTextWithMarkup = function(text, x, y, scale, maxWidth){
        if (maxWidth<1) return;
        let lastMarkup = {raw: "&8", isBold: false, isItalic: false}
        let lines = 0
        let nextText = text.replace(urlRegex,"⭍&9$1⭍&r").replace(basicUrlRegex,"⭍&9$&⭍&r")
        while(nextText){
            let string = this._addMCMarkupToString(nextText, "&8",lastMarkup)

            let string1Split = string.string.split(" ")
            let string2Split = nextText.split(" ")

            let checkI = 0
            let checkStringTemp = "" //totally understandable var names go here
            let checkStringTemp2 = "" //totally understandable var names go here
            let isOverMaxWidth = false
            nextText = undefined
            while(checkI < string1Split.length){
                if(isOverMaxWidth){
                    nextText += " " + string2Split[checkI]
                }
                if(Renderer.getStringWidth(checkStringTemp + string1Split[checkI]) > maxWidth/scale && !isOverMaxWidth && checkI>0){
                    isOverMaxWidth = true
                    nextText = string2Split[checkI]
                }

                if(!isOverMaxWidth){
                    checkStringTemp += string1Split[checkI] + " "
                    checkStringTemp2 += string2Split[checkI] + " "
                }

                checkI ++
            }

            this.drawString(checkStringTemp,x,y+8*lines*scale,scale)
            lastMarkup = this._addMCMarkupToString(checkStringTemp2, "&8",lastMarkup).markup
            lines++
        }
        if(lines === 0){
            lines++
        }
        return lines*8*scale;
    }
    _addMCMarkupToString = function(string, color, lastMarkup){
        let ret = {string: color}

        let isBold = false
        let isItalic = false
        if(lastMarkup){
            isBold = lastMarkup.isBold
            isItalic = lastMarkup.isItalic
            ret.markup = lastMarkup
            ret.string += ret.markup.raw
        }

        let lastChar = ""
        let lastChar2 = ""
        let lastChar3 = ""
        let charArr = string.replace(urlRegex,"⭍&9$1⭍&r").replace(basicUrlRegex,"⭍&9$&⭍&r").split("")
        urlRegex.lastIndex = 0
        basicUrlRegex.lastIndex = 0
        charArr.push("")
        charArr.push("")
        charArr.push("")
        charArr.forEach((char)=>{

            if(char !== "_" && char !== "*"){
                if(lastChar === "_" || lastChar === "*"){
                    if(lastChar2 === "_" || lastChar2 === "*"){
                        if(lastChar3 === "_" || lastChar3 === "*"){
                            isBold = !isBold
                            isItalic = !isItalic
                        }else{
                            isBold = !isBold
                        }
                    }else{
                        isItalic = !isItalic
                    }

                    ret.markup = {raw: "", isItalic: isItalic, isBold: isBold}
                    ret.markup.raw += "&r"
                    ret.markup.raw += color
                    if(isBold){
                        ret.markup.raw += "&l"
                    }
                    if(isItalic){
                        ret.markup.raw += "&o"
                    }
                    ret.string += ret.markup.raw
                }
                
                if(lastChar === "&" && lastChar2 === "⭍"){
                    ret.string += char
                    if(char === "r"){
                        ret.string += color
                    }
                    if(isBold){
                        ret.string += "&l"
                    }
                    if(isItalic){
                        ret.string += "&o"
                    }
                }else{
                    if(char === "&" && lastChar !== "⭍"){
                        ret.string += "&⭍"
                    }else{
                        ret.string += char
                    }
                }
            }

            lastChar3 = lastChar2
            lastChar2 = lastChar
            lastChar = char
        })

        return ret
    }
    splitStringAtWidth = function(string, width){
        let ret = []
        let currLen = 0
        let lastStr = ""
        let first = true
        string.split(" ").forEach((str)=>{
            if(Renderer.getStringWidth(lastStr + " " + str) > width){
                ret.push(lastStr)
                currLen = 0
                lastStr = str
            }else{
                lastStr += (first?"":" ") + str
                first = false
            }
            currLen+=Renderer.getStringWidth(str)
        })
        ret.push(lastStr)
        return ret;
    }
}

let renderLibs = new RenderLibs()

export default renderLibs;


/**
 * Returns intersecting part of two rectangles
 * @param  {object}  r1 4 coordinates in form of {x1, y1, x2, y2} object
 * @param  {object}  r2 4 coordinates in form of {x1, y1, x2, y2} object
 * @return {boolean}    False if there's no intersecting part
 * @return {object}     4 coordinates in form of {x1, y1, x2, y2} object
 */
const getIntersectingRectangle = (r1, r2) => {  
    [r1, r2] = [r1, r2].map(r => {
      return {
        x: [r.x1, r.x2].sort((a,b) => a - b),
        y: [r.y1, r.y2].sort((a,b) => a - b)
      };
    });
  
    const noIntersect = r2.x[0] > r1.x[1] || r2.x[1] < r1.x[0] ||
                        r2.y[0] > r1.y[1] || r2.y[1] < r1.y[0];
  
    return noIntersect ? false : {
      x1: Math.max(r1.x[0], r2.x[0]), // _[0] is the lesser,
      y1: Math.max(r1.y[0], r2.y[0]), // _[1] is the greater
      x2: Math.min(r1.x[1], r2.x[1]),
      y2: Math.min(r1.y[1], r2.y[1])
    };
  };
  