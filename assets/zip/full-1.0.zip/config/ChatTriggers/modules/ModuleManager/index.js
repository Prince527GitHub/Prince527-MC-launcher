/// <reference types="../CTAutocomplete" />
/// <reference lib="es2015" />

const File = Java.type("java.io.File")

import renderLibs from 'modulemanager/renderLibs.js';

let gui = new Gui()

let guiData = {
    openedTime: 0,
    title: "&cLOADING...",
    modulePane: {
        x: 0
    },
    moduleInfo: {
        scroll: 0,
        scrollRender: 0,
        scrollRenderLast: 0
    },
    openedImage: false,
    openedImageTime: 0,
    scroll: 0,
    scrollRender: 0,
    scrollRenderLast: 0,
    search: "",
    searching: false,
    searchingTime: 0,
    lastSearch: "You should never need to search this -_-",
    selected: undefined,
    selectedTime: 0,
    scrollToTopShownTime: 0,
    showScrollToTop: false
}
let modulesShown = []
gui.registerDraw(guiRender)
gui.registerScrolled(guiScrolledFunction);
gui.registerClicked(guiClickedFunction);
gui.registerKeyTyped(guiTypedFunction)

let lastRenderLocs= {
    search: [0,0,0,0],
    modules: [],
    moduleInfoPane: [0,0,0,0],
    moduleSearchPane: [0,0,0,0],
    image: [0,0,0,0],
    imgClose: [0,0],
    searchTabTop: [0,0],
    importButton: [0,0,0,0]
}

register("tick",()=>{
    guiData.scrollRenderLast = guiData.scrollRender
    guiData.scrollRender -= (guiData.scrollRender-guiData.scroll)/10
    guiData.moduleInfo.scrollRenderLast = guiData.moduleInfo.scrollRender
    guiData.moduleInfo.scrollRender -= (guiData.moduleInfo.scrollRender-guiData.moduleInfo.scroll)/10
    
    if(guiData.scroll < -1000){
        if(!guiData.showScrollToTop){
            guiData.showScrollToTop = true
            guiData.scrollToTopShownTime = new Date().getTime()
        }
    }else{
        if(guiData.showScrollToTop){
            guiData.showScrollToTop = false
            guiData.scrollToTopShownTime = new Date().getTime()
        }
    }

    if(guiData.search !== guiData.lastSearch){
        let modulesShown1 = modulesData
        modulesShown1 = modulesShown1.filter((a)=>{
            return a.name.toLowerCase().includes(guiData.search.toLowerCase())
        })
        let modulesShown2 = modulesData
        modulesShown2 = modulesShown2.filter((a)=>{
            return (a.owner.name || "").toLowerCase().includes(guiData.search.toLowerCase()) && !modulesShown1.includes(a)
        })
        let modulesShown3 = modulesData
        modulesShown3 = modulesShown3.filter((a)=>{
            return a.description.toLowerCase().includes(guiData.search.toLowerCase()) && !modulesShown1.includes(a) && !modulesShown2.includes(a)
        })
        modulesShown = [...modulesShown1,...modulesShown2]
        if(guiData.lastSearch !== "You should never need to search this -_-"){
            guiData.scroll = 0
        }
        guiData.lastSearch = guiData.search
        
    }
})

let stopRender = false
function guiRender(mouseX, mouseY, partialTicks){
    if(stopRender) return;
    let now = new Date().getTime()
    let openAnimationProgress = Math.min(1,(now-guiData.openedTime)/1000)

    openAnimationProgress = Math.sin(degrees_to_radians(openAnimationProgress*90))

    let width = Renderer.screen.getWidth()
    let height = Renderer.screen.getHeight()

    Renderer.drawRect(Renderer.color(0,0,0,openAnimationProgress*100),0,0,width,height)

    if(guiData.selected === undefined){
        let selectedAnimationProgress = Math.max(0,Math.min(1,(guiData.selectedTime+1000-now)/1000))
        selectedAnimationProgress = (Math.sin(degrees_to_radians(selectedAnimationProgress*180-90))+1)/2

        guiData.modulePane.x =  0-(width/5)*selectedAnimationProgress
    }else{
        let selectedAnimationProgress = Math.min(1,(now-guiData.selectedTime)/1000)
        selectedAnimationProgress = (Math.sin(degrees_to_radians(selectedAnimationProgress*180-90))+1)/2

        guiData.modulePane.x =  0-(width/5)*selectedAnimationProgress
        drawModuleInfoPane(partialTicks)
    }
    drawModulePane(partialTicks)

    renderLibs.drawStringCenteredFull(guiData.title,width/2,50*openAnimationProgress,3*openAnimationProgress)

    
    if(guiData.openedImage){
        let imageAnimationProgress = Math.max(0,Math.min(1,-(guiData.openedImageTime-now)/1000))
        imageAnimationProgress = (Math.sin(degrees_to_radians(imageAnimationProgress*180-90))+1)/2

        Renderer.drawRect(Renderer.color(0,0,0,100*imageAnimationProgress),0,0,width, height)

        let imageScale = Infinity

        imageScale = Math.min(imageScale,(width/4*3)/guiData.openedImage.getTextureWidth())
        imageScale = Math.min(imageScale,(height/4*3)/guiData.openedImage.getTextureHeight())

        let imgWidth = guiData.openedImage.getTextureWidth()*imageScale*imageAnimationProgress
        let imgHeight = guiData.openedImage.getTextureHeight()*imageScale*imageAnimationProgress
        

        guiData.openedImage.draw(width/2-imgWidth/2,height/2-imgHeight/2,imgWidth, imgHeight)

        Renderer.drawCircle(Renderer.color(251-60, 255-60, 204-60),width/2+imgWidth/2,height/2-imgHeight/2,13*openAnimationProgress,15)
        Renderer.drawCircle(Renderer.color(251, 255, 204),width/2+imgWidth/2,height/2-imgHeight/2,10*openAnimationProgress,15)
        renderLibs.drawStringCenteredFull("&cX",width/2+imgWidth/2+1,height/2-imgHeight/2+7+1,2*openAnimationProgress)

        lastRenderLocs.imgClose = [width/2+imgWidth/2,height/2-imgHeight/2]
    }else{
        //lastRenderLocs.importButton = [x+paneWidth/2-buttonWidth-5,height-125+5,buttonWidth,buttonHeight,guiData.selected.name,["Click to install!"]]
        if(mouseX > lastRenderLocs.importButton[0] && mouseY > lastRenderLocs.importButton[1] && mouseX < lastRenderLocs.importButton[0]+lastRenderLocs.search[2] && mouseY < lastRenderLocs.importButton[1]+lastRenderLocs.importButton[3]){
            Client.currentGui.get().func_146283_a(lastRenderLocs.importButton[5], mouseX,mouseY)
        }
    }
}

function drawModuleInfoPane(partialTicks){
    let width = Renderer.screen.getWidth()
    let height = Renderer.screen.getHeight()
    let now = new Date().getTime()
    
    let openAnimationProgress = Math.max(0,Math.min(1,(now-guiData.selectedTime-300)/1000))
    let scrollRender = guiData.moduleInfo.scrollRenderLast + (guiData.moduleInfo.scrollRender-guiData.moduleInfo.scrollRenderLast)*partialTicks

    let x = width/5*2.75-guiData.modulePane.x
    let y = 100
    let paneWidth = width/5*1.5

    renderLibs.scizzor(x-paneWidth/2,100,paneWidth,Math.max(0,(height-150-100)*openAnimationProgress))
    renderLibs.drawBox([253, 255, 227],x-paneWidth/2,100,paneWidth,height-150-100,3)
    
    renderLibs.scizzor(x-paneWidth/2+3,100+3,paneWidth-6,Math.max(0,(height-150-100)*openAnimationProgress-6))

    let renderX = x-paneWidth/2+5
    let renderY = y+5+scrollRender
    let renderHeight = 0
    
    renderLibs.drawStringResiseWidth("&8" + guiData.selected.name,renderX, renderY, 3,paneWidth-6-4-5)
    renderHeight += 7*3+2

    renderLibs.drawStringResiseWidth("&8By " + guiData.selected.owner.name, renderX,renderY+renderHeight,1.5,paneWidth-6-4-5)
    renderHeight += 7*1.5+2

    if(guiData.selected.drawImage){
        
        let imageScale = Infinity

        imageScale = Math.min(imageScale,(paneWidth-13)/guiData.selected.drawImage.getTextureWidth())
        imageScale = Math.min(imageScale,200/guiData.selected.drawImage.getTextureHeight())
        
        guiData.selected.drawImage.draw(renderX, renderY+renderHeight,guiData.selected.drawImage.getTextureWidth()*imageScale,guiData.selected.drawImage.getTextureHeight()*imageScale)

        lastRenderLocs.image = [renderX, renderY+renderHeight,guiData.selected.drawImage.getTextureWidth()*imageScale,guiData.selected.drawImage.getTextureHeight()*imageScale]

        renderHeight += guiData.selected.drawImage.getTextureHeight()*imageScale
    }else{
        lastRenderLocs.image = [0,0,0,0]
    }
    renderHeight += 5
    
    textBlockRet = renderLibs.renderTextBlockWithMarkup(guiData.selected.description,renderX,renderY+renderHeight,paneWidth-6-4-5)
    renderHeight += textBlockRet.height

    lastRenderLocs.imageClickData = textBlockRet.imageClickData

    lastRenderLocs.moduleInfoPane = [x-paneWidth/2,100,paneWidth,height-150-100,renderHeight]

    renderLibs.stopScizzor()

    Renderer.drawCircle(Renderer.color(251-60, 255-60, 204-60),x+paneWidth/2-3,100+3,13*openAnimationProgress,15)
    Renderer.drawCircle(Renderer.color(251, 255, 204),x+paneWidth/2-3,100+3,10*openAnimationProgress,15)
    renderLibs.drawStringCenteredFull("&cX",x+paneWidth/2-3+1,100+3+7+1,2*openAnimationProgress)

    renderLibs.drawBox([253, 255, 227],x-paneWidth/2,height-125,paneWidth*openAnimationProgress,75,3)
    renderLibs.scizzor(x-paneWidth/2+3,height-125+3,paneWidth*openAnimationProgress-6,75-6)
    
    renderHeight = 0
    lastRenderLocs.importButton = [0,0,0,0]
    if(guiData.selected.localData === undefined){
        if(guiData.selected.releases.length !== 0){
            renderLibs.drawString("&cIMPORT &8v" + guiData.selected.releases[0].releaseVersion + " (ct " + guiData.selected.releases[0].modVersion + ")",x-paneWidth/2+3+3,height-125+3+3,1.5)
            
            let buttonWidth = Renderer.getStringWidth("Import")+5+5
            let buttonHeight = 20
            renderLibs.drawBox([251, 255, 204],x+paneWidth/2-buttonWidth-5,height-125+5,buttonWidth,buttonHeight,3)
            renderLibs.drawStringCenteredVertically("&7Import",x+paneWidth/2-buttonWidth,height-125+buttonHeight/2+5,1)

            lastRenderLocs.importButton = [x+paneWidth/2-buttonWidth-5,height-125+5,buttonWidth,buttonHeight,"ct import " + guiData.selected.name,["Click to install!"]]// todo:  add lore telling what modules it requires

            renderLibs.drawString("&7Module Total Downloads: " + guiData.selected.downloads,x-paneWidth/2+3+3,height-125+3+3+16,1)
            renderLibs.drawString("&7Release Downloads: " + guiData.selected.releases[0].downloads,x-paneWidth/2+3+3,height-125+3+3+16+8,1)
        }else{
            renderLibs.drawString("&cNO RELEASES!?!?!?!",x-paneWidth/2+3+3,height-125+3+3,1.5)
        }
    }else{            
        if(guiData.selected.localOnly){
            renderLibs.drawString("&cLocal version &8v" + guiData.selected.localData.version,x-paneWidth/2+3+3,height-125+3+3,1.5)
            renderLibs.drawString("&c(Not uploaded!)",x-paneWidth/2+3+3,height-125+3+3+8*1.5,1.5)
            
        }else{
            renderLibs.drawString("&cLocal version &8v" + guiData.selected.localData.version ,x-paneWidth/2+3+3,height-125+3+3,1.5,paneWidth-10)
            renderLibs.drawStringResiseWidth("&cUploaded version &8" + (guiData.selected.releases.length === 0?"NONE":"v" + guiData.selected.releases[0].releaseVersion + " (ct " + guiData.selected.releases[0].modVersion + ")"),x-paneWidth/2+3+3,height-125+3+3+8*1.5,1.5,paneWidth-20-Renderer.getStringWidth("Delete")-2)
        
            renderLibs.drawString("&7Module Total Downloads: " + guiData.selected.downloads,x-paneWidth/2+3+3,height-125+3+3+16+8*1.5,1)
            if(guiData.selected.releases.length !== 0){
                renderLibs.drawString("&7Release Downloads: " + guiData.selected.releases[0].downloads,x-paneWidth/2+3+3,height-125+3+3+16+8+8*1.5,1)
            }
        }

        let buttonWidth = Renderer.getStringWidth("Delete")+5+5
        let buttonHeight = 20
        renderLibs.drawBox([251, 255, 204],x+paneWidth/2-buttonWidth-5,height-125+5,buttonWidth,buttonHeight,3)
        renderLibs.drawStringCenteredVertically("&7Delete",x+paneWidth/2-buttonWidth,height-125+buttonHeight/2+5,1)

        lastRenderLocs.importButton = [x+paneWidth/2-buttonWidth-5,height-125+5,buttonWidth,buttonHeight,"ct delete " + guiData.selected.name,["Click to delete!"]]

    }
}

function guiClickedFunction(mouseX, mouseY, button) {
    if(button === 0){

        if(guiData.openedImage) {
            if(Math.pow(mouseX-lastRenderLocs.imgClose[0], 2) + Math.pow(mouseY-lastRenderLocs.imgClose[1], 2) < 13*13){
                guiData.openedImage = false
                guiData.openedImageTime = new Date().getTime()
            }
            return
        }

        if(guiData.showScrollToTop){
            if(Math.pow(mouseX-lastRenderLocs.searchTabTop[0], 2) + Math.pow(mouseY-lastRenderLocs.searchTabTop[1], 2) < 13*13){
                guiData.scroll = 0
            }
        }

        if(mouseX > lastRenderLocs.search[0] && mouseY > lastRenderLocs.search[1] && mouseX < lastRenderLocs.search[0]+lastRenderLocs.search[2] && mouseY < lastRenderLocs.search[1]+lastRenderLocs.search[3]){
            guiData.searching = true
            guiData.searchingTime = new Date().getTime()
        }else{
            guiData.searching = false
        }
        if((mouseX > lastRenderLocs.moduleInfoPane[0] && mouseY > lastRenderLocs.moduleInfoPane[1] && mouseX < lastRenderLocs.moduleInfoPane[0]+lastRenderLocs.moduleInfoPane[2] && mouseY < lastRenderLocs.moduleInfoPane[1]+lastRenderLocs.moduleInfoPane[3])){
            if(mouseX > lastRenderLocs.image[0] && mouseY > lastRenderLocs.image[1] && mouseX < lastRenderLocs.image[0]+lastRenderLocs.search[2] && mouseY < lastRenderLocs.image[1]+lastRenderLocs.image[3]){
                if(guiData.selected !== undefined){
                    guiData.openedImage = guiData.selected.drawImage
                    guiData.openedImageTime = new Date().getTime()
                }
            }
            lastRenderLocs.imageClickData.forEach((data)=>{
                if(mouseX > data[0] && mouseY > data[1] && mouseX < data[0]+data[2] && mouseY < data[1]+data[3]){
                    if(guiData.selected !== undefined){
                        guiData.openedImage = data[4]
                        guiData.openedImageTime = new Date().getTime()
                    }
                }
            })
        }
        //lastRenderLocs.importButton = [x+paneWidth/2-buttonWidth-5,height-125+5,buttonWidth,buttonHeight,guiData.selected.name,["Click to install!"]]
        if(mouseX > lastRenderLocs.importButton[0] && mouseY > lastRenderLocs.importButton[1] && mouseX < lastRenderLocs.importButton[0]+lastRenderLocs.search[2] && mouseY < lastRenderLocs.importButton[1]+lastRenderLocs.importButton[3]){
            ChatLib.command(lastRenderLocs.importButton[4],true)
            Client.showTitle("&cLoading...","",20,10000,0)
            stopRender = true
            new Thread(()=>{
                FileLib.write("ModuleManager","loadNewModuleData.json",JSON.stringify({loading: true,selected: guiData.selected.name,scroll: guiData.scroll,search: guiData.search}))
                if(lastRenderLocs.importButton[4].startsWith("ct import ")){
                    Thread.sleep(1000)
                    ChatLib.command("ct load",true)
                }
            }).start()
        }
        
        lastRenderLocs.modules.forEach((info)=>{
            if(mouseX > info.loc[0] && mouseY > info.loc[1] && mouseX < info.loc[0]+info.loc[2] && mouseY < info.loc[1]+info.loc[3]){
                if(guiData.selected === undefined){
                    guiData.selectedTime = new Date().getTime()
                }
                guiData.selected = info.module
                guiData.moduleInfo.scroll = 0
            }
        })

        if(guiData.selected !== undefined){
            if(new Date().getTime()-guiData.selectedTime > 1300){
                let x = Renderer.screen.getWidth()/5*2.75-guiData.modulePane.x
                let paneWidth = Renderer.screen.getWidth()/5*1.5
                if(Math.pow((mouseX-(x+paneWidth/2-3)), 2) + Math.pow((mouseY-103), 2) < 13*13){
                    guiData.selected = undefined
                    guiData.selectedTime = new Date().getTime()
                }
            }
        }
    }
}

function guiTypedFunction(char, keyCode){
    if(guiData.searching){
        switch(keyCode){
            case 42:
            case 29:
                break;
            case 14: 
                if(gui.isControlDown()){
                    guiData.search= guiData.search.split(" ")
                    guiData.search.pop()
                    guiData.search= guiData.search.join(" ")
                }else{
                    guiData.search = guiData.search.substr(0,guiData.search.length-1)
                }
                break;
            default: 
                guiData.search += char
        }
    }
}

function guiScrolledFunction(mouseX, mouseY, direction) {
    if(guiData.openedImage) {
        return
    }
    if((mouseX > lastRenderLocs.moduleSearchPane[0] && mouseY > lastRenderLocs.moduleSearchPane[1] && mouseX < lastRenderLocs.moduleSearchPane[0]+lastRenderLocs.moduleSearchPane[2] && mouseY < lastRenderLocs.moduleSearchPane[1]+lastRenderLocs.moduleSearchPane[3])){
        guiData.scroll += direction*50
        guiData.scroll = Math.min(0,guiData.scroll)
    }
    if((mouseX > lastRenderLocs.moduleInfoPane[0] && mouseY > lastRenderLocs.moduleInfoPane[1] && mouseX < lastRenderLocs.moduleInfoPane[0]+lastRenderLocs.moduleInfoPane[2] && mouseY < lastRenderLocs.moduleInfoPane[1]+lastRenderLocs.moduleInfoPane[3])){
        guiData.moduleInfo.scroll += direction*50
        guiData.moduleInfo.scroll = Math.max(Math.min(0,guiData.moduleInfo.scroll),Math.min(-lastRenderLocs.moduleInfoPane[4]-10+lastRenderLocs.moduleInfoPane[3],0))
    }
}

function drawModulePane(partialTicks){
    let width = Renderer.screen.getWidth()
    let height = Renderer.screen.getHeight()
    let now = new Date().getTime()
    
    let openAnimationProgress = Math.max(0,Math.min(1,(now-guiData.openedTime-300)/1000))
    let scrollRender = guiData.scrollRenderLast + (guiData.scrollRender-guiData.scrollRenderLast)*partialTicks

    let x = width/2+guiData.modulePane.x
    let paneWidth = width/2

    renderLibs.scizzor(x-paneWidth/4,70,paneWidth/2*openAnimationProgress,25)
    renderLibs.drawBox([253, 255, 227],x-paneWidth/4,70,paneWidth/2,25,3)
    if(openAnimationProgress !== 0){
        renderLibs.scizzor(x-paneWidth/4+3,70+3,Math.max(0,paneWidth/2*openAnimationProgress-7),25-6)

        lastRenderLocs.search = [x-paneWidth/4+3,70+3,Math.max(0,paneWidth/2*openAnimationProgress-7),25-6]
        if(guiData.searching){
            renderLibs.drawStringCenteredVertically("&8" + guiData.search + ((new Date().getTime()-guiData.searchingTime)%1000>500?"_":""),x-paneWidth/4+4-Math.max(0,Renderer.getStringWidth(guiData.search + "_")-paneWidth/2+8),70+25/2,1)
        }else{
            renderLibs.drawStringCenteredVertically(guiData.search===""?"&7Search Here":"&8"+guiData.search,x-paneWidth/4+4,70+25/2,1)
        }
    }
    renderLibs.stopScizzor()

    renderLibs.scizzor(x-paneWidth/2,100,paneWidth,Math.max(0,(height-150)*openAnimationProgress))
    renderLibs.drawBox([253, 255, 227],x-paneWidth/2,100,paneWidth,height-150,3)

    lastRenderLocs.modules = []
    let drawY = 100+scrollRender
    modulesShown.forEach((mod)=>{
        if(drawY > height)return;
        renderLibs.stopScizzor()
        renderLibs.scizzor(x-paneWidth/2,100,paneWidth,Math.max(0,(height-150)*openAnimationProgress))
        renderLibs.scizzor(x-paneWidth/2+3,100+3,paneWidth-6,(height-150-6))
        drawY += drawModule(mod, x, drawY, paneWidth, now)
    })
    
    lastRenderLocs.moduleSearchPane = [x-paneWidth/2,100,paneWidth,height-150,drawY]
    renderLibs.stopScizzor()

    let scrollAnimationProgress = 0
    if(guiData.showScrollToTop){
        scrollAnimationProgress = Math.max(0,Math.min(1,-(guiData.scrollToTopShownTime-now)/1000))
    }else{
        scrollAnimationProgress= Math.max(0,Math.min(1,-(now-guiData.scrollToTopShownTime-1000)/1000))
    }
    scrollAnimationProgress = (Math.sin(degrees_to_radians(scrollAnimationProgress*180-90))+1)/2
    
    if(scrollAnimationProgress>0){

        Renderer.drawCircle(Renderer.color(251-60, 255-60, 204-60),x+paneWidth/2,100,13*scrollAnimationProgress,15)
        Renderer.drawCircle(Renderer.color(251, 255, 204),x+paneWidth/2,100,10*scrollAnimationProgress,15)
        Renderer.drawShape(Renderer.color(170, 0, 0),[x+paneWidth/2,100-6*scrollAnimationProgress],[x+paneWidth/2-5*scrollAnimationProgress,100+5*scrollAnimationProgress],[x+paneWidth/2+5*scrollAnimationProgress,100+5*scrollAnimationProgress],[x+paneWidth/2,100-6*scrollAnimationProgress])
            
        lastRenderLocs.searchTabTop = [x+paneWidth/2,100]
    }
}

function drawModule(mod, x, drawY, paneWidth, now){
    let openAnimationProgress = Math.min(1,(now-mod.loadedTime)/300)

    openAnimationProgress = Math.sin(degrees_to_radians(openAnimationProgress*90))
    
    let height = 100
    let renderX = x-paneWidth/2*3+5+(paneWidth*openAnimationProgress)
    let renderY = drawY+5
    let renderWidth = paneWidth-10
    let renderHeight = height-10
    
    if(renderY+renderHeight > 100 && renderY < Renderer.screen.getHeight()-50){
        if(mod.loadedTime === undefined && mod.loading=== undefined){
            modulesData[mod.moduleListI].loading = true
            new Thread(()=>{
                if(mod.image !== null && mod.image !== ""){
                    mod.drawImage = new Image("mm_" + mod.id,mod.image)
                }else{
                    mod.drawImage = null
                }
                mod.loadedTime = new Date().getTime()
                mod.loading = false
                modulesData[mod.moduleListI] = mod
            }).start()
        }else{
            textOffX = 0
            if(mod.drawImage || mod.drawImage2){
                textOffX += 93
            }
            renderLibs.drawBox([251, 255, 204],renderX,renderY,renderWidth,renderHeight,3)
            if(renderY+renderHeight-6 > 100 && renderY+6 < Renderer.screen.getHeight()-50 && renderX+renderWidth-6 > x-paneWidth/2 && renderX+3 < x+paneWidth/2){
                renderLibs.scizzor(renderX+3,renderY+3,renderWidth-6,renderHeight-6)
                renderLibs.drawStringResiseWidth("&8" + mod.name + (mod.localData !== undefined?" &7(Installed)":""),renderX+5+textOffX, renderY+5,2,renderWidth-5)

                lastRenderLocs.modules.push({
                    loc: renderLibs.getCurrScizzor(),
                    module: mod
                })
                if(mod.drawImage){
                    let imageScale = Infinity

                    imageScale = Math.min(imageScale,90/mod.drawImage.getTextureWidth())
                    imageScale = Math.min(imageScale,80/mod.drawImage.getTextureHeight())
                    
                    mod.drawImage.draw(renderX+5, renderY+5,mod.drawImage.getTextureWidth()*imageScale,mod.drawImage.getTextureHeight()*imageScale)
                }else{
                    if(mod.drawImage2){
                        let imageScale = Infinity
    
                        imageScale = Math.min(imageScale,90/mod.drawImage2.getTextureWidth())
                        imageScale = Math.min(imageScale,80/mod.drawImage2.getTextureHeight())
                        
                        mod.drawImage2.draw(renderX+5, renderY+5,mod.drawImage2.getTextureWidth()*imageScale,mod.drawImage2.getTextureHeight()*imageScale)
                    }
                }

                let images = renderLibs.renderTextBlockWithMarkup(mod.description,renderX+5+textOffX,renderY+5+17,renderWidth-5-textOffX-5).imageClickData
                if(images.length > 0){
                    mod.drawImage2 = images[0][4]
                }

            }
        } 
    }

    return height
}

register("command",()=>{
    reloadGui()
    new Thread(()=>{
        loadModules()
    }).start()
}).setName("modules")

function reloadGui(){
    gui.open()
    guiData.openedTime = new Date().getTime()
    guiData.title = "&cLOADING..."
    guiData.loadedModules = false
    guiData.scroll = 0
    guiData.scrollRender = 0
    guiData.scrollRenderLast = 0
    guiData.moduleInfo.scrollRender = 0
    guiData.moduleInfo.scrollRenderLast = 0
    guiData.moduleInfo.scroll = 0
    guiData.search = ""
    guiData.searching = false
    guiData.searchingTime = 0
    guiData.lastSearch = "You should never need to search this -_-"
    guiData.selected = undefined
    guiData.selectedTime = 0
    guiData.openedImage = false
    guiData.openedImageTime = 0
    modulesData = []
}

let modulesData = []

let loadingModules = false
function loadModules(){
    if(loadingModules) return;
    loadingModules = true
    let response = JSON.parse(FileLib.getUrlContent("https://chattriggers.com/api/modules?limit=999999&offset=0&sort=DATE_CREATED_DESC"))

    let modulesLocal = getLocalModules()

    let modulesInListString = []

    response.modules.forEach((moduleData, i)=>{
        moduleData.moduleListI = i
        if(modulesLocal[moduleData.name.toLowerCase()] !== undefined){
            moduleData.localData = modulesLocal[moduleData.name.toLowerCase()]
        }
        modulesData[i] = moduleData
        
        modulesInListString.push(moduleData.name.toLowerCase())
    })

    Object.values(modulesLocal).forEach((module)=>{
        if(!modulesInListString.includes(module.name.toLowerCase())){
            module.localData = module
            module.moduleListI = modulesData.length
            module.image = null
            module.owner = {name: module.author}
            module.localOnly = true
            modulesData.push(module)
        }
    })

    guiData.loadedModules = true
    guiData.title = "&aModules"
    guiData.lastSearch = "You should never need to search this -_-"
    loadingModules = false
}

function getLocalModules(){
    let ret = {}
    modulesDir = new File("./config/ChatTriggers/modules")

    modulesDir.list().forEach((pathName)=>{
        if(pathName.includes(".")) return;

        try{
            let data = JSON.parse(FileLib.read(pathName,"metadata.json"))
            data.name = pathName
            if(data === null){ 
                return;
            }
            ret[pathName.toLowerCase()] = data
        }catch(_e){}
    })

    return ret;
}

function degrees_to_radians(degrees)
{
  var pi = Math.PI;
  return degrees * (pi/180);
}

let updateNewModuleData = {}
new Thread(()=>{
    updateNewModuleData = JSON.parse(FileLib.read("ModuleManager","loadNewModuleData.json"))

    if(updateNewModuleData.loading){
        Client.showTitle("&cLoading...","",0,0,20)
        reloadGui()
        guiData.search = updateNewModuleData.search
        loadModules()
        guiData.loadedModules = true
        guiData.title = "&aModules"
        guiData.lastSearch = "You should never need to search this -_-"
        loadingModules = false

        modulesData.forEach((mod)=>{
            if(mod.name === updateNewModuleData.selected){
                guiData.selected = mod
            }
        })

        guiData.scroll = updateNewModuleData.scroll
        guiData.search = updateNewModuleData.search
        guiData.scrollRender = updateNewModuleData.scroll
        guiData.scrollRenderLast = updateNewModuleData.scroll

    }
    
    FileLib.write("ModuleManager","loadNewModuleData.json","{}")
}).start()