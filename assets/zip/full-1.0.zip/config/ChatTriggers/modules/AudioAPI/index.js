const File = java.io.File;
const StreamPlayer = Java.type(
  "com.goxr3plus.streamplayer.stream.StreamPlayer"
);
const StreamPlayerListener = Java.type(
  "com.goxr3plus.streamplayer.stream.StreamPlayerListener"
);
const StreamPlayerEvent = Java.type(
  "com.goxr3plus.streamplayer.stream.StreamPlayerEvent"
);

export default class AudioPlayer {
  /**
   * Audio Player API
   */
  constructor() {
    let self = this;
    this.player = new JavaAdapter(StreamPlayer, StreamPlayerListener, {
      /**
       *
       * @param {Object} dataSource
       * @param {Object<String,Object>} properties
       */
      opened(dataSource, properties) {},
      /**
       *
       * @param {Number} nEncodedBytes
       * @param {Number} microsecondPosition
       * @param {*} pcmData
       * @param {Object<String,Object>} properties
       */
      progress(nEncodedBytes, microsecondPosition, pcmData, properties) {},

      /**
       *
       * @param {StreamPlayerEvent} streamPlayerEvent
       */
      statusUpdated(streamPlayerEvent) {},
    });

    this.player.addStreamPlayerListener(this.player);

    register("gameUnload", () => {
      if (this.isPausedOrPlaying()) this.stop();
      this.player.removeStreamPlayerListener(this.player);
    });
  }

  /**
   * Calculates the current position of the encoded audio based on
   * nEncodedBytes = encodedAudioLength -
   * encodedAudioInputStream.available();
   *
   * @returns {Number} The Position of the encoded stream in term of bytes
   */
  getEncodedStreamPosition() {
    return this.player.getEncodedStreamPosition();
  }

  /**
   * Return the total size of this file in bytes.
   *
   * @return {Number} encodedAudioLength
   */
  getTotalBytes() {
    return this.player.getTotalBytes();
  }

  /**
   * @return {Number} The position of the track in seconds
   */
  getPositionInSeconds() {
    return Math.floor(this.getPositionInMilliseconds() / 1e3);
  }

  /**
   * @return {Number} The position of the track in milliseconds
   */
  getPositionInMilliseconds() {
    const totalBytes = this.getTotalBytes();
    const currentByte = this.getEncodedStreamPosition();
    const milliDuration = this.getDurationInMilliseconds();
    const bytePerMilli = totalBytes / milliDuration;

    return Math.floor(currentByte / bytePerMilli);
  }

  /**
   * Open the specified file for playback.
   * @param {File} file
   */
  open(file) {
    this.player.open(file);
  }

  /**
   * Starts the playback.
   */
  play() {
    this.player.play();
  }

  /**
   * Pauses the playback.
   *
   * @returns {boolean}
   */
  pause() {
    return this.player.pause();
  }

  /**
   * Stops the playback.
   */
  stop() {
    this.player.stop();
  }

  /**
   * Resumes the playback.
   *
   * @returns {boolean}
   */
  resume() {
    return this.player.resume();
  }

  /**
   * Skip x seconds of audio
   * @param {Number} seconds
   */
  seekSeconds(seconds) {
    try {
      return this.player.seekSeconds(Math.floor(seconds));
    } catch (e) {}
  }

  /**
   * Go to X time of the Audio
   * @param {Number} seconds
   */
  seekTo(seconds) {
    try {
      return this.player.seekTo(Math.floor(seconds));
    } catch (e) {}
  }

  /**
   * Checks if is playing.
   *
   * @returns {boolean} true if player is playing, false if not.
   */
  isPlaying() {
    return this.player.isPlaying();
  }

  /**
   * Checks if is paused.
   *
   * @returns {boolean} true if player is paused, false if not.
   */
  isPaused() {
    return this.player.isPaused();
  }

  /**
   * Checks if is paused.
   *
   * @returns {boolean} true if player is paused/playing, false if not.
   */
  isPausedOrPlaying() {
    return this.isPlaying() || this.isPaused();
  }

  /**
   * Checks if is stopped.
   *
   * @returns {boolean} true if player is stopped, false if not.
   */
  isStopped() {
    return this.player.isStopped();
  }

  /**
   * Checks if is opened.
   *
   * @returns {boolean} true if player is opened, false if not.
   */
  isOpened() {
    return this.player.isOpened();
  }

  /**
   * Checks if is seeking.
   *
   * @returns {boolean} true if player is seeking, false if not.
   */
  isSeeking() {
    return this.player.isSeeking();
  }

  /**
   * @returns {Number} The duration of the source data in seconds, or -1 if duration is unavailable.
   */
  getDurationInSeconds() {
    return this.player.getDurationInSeconds();
  }

  /**
   * @returns {Number} The duration of the source data in milliseconds, or -1 if duration is unavailable.
   */
  getDurationInMilliseconds() {
    return this.player.getDurationInMilliseconds();
  }

  /**
   * Change the Speed Rate of the Audio , this variable affects the Sample Rate ,
   * for example 1.0 is normal , 0.5 is half the speed and 2.0 is double the speed
   * Note that you have to restart the audio for this to take effect
   * @param {Number} speedFactor
   */
  setSpeedFactor(speedFactor) {
    this.player.setSpeedFactor(speedFactor);
    if (this.isPlaying()) {
      let position = this.getPositionInSeconds();
      this.stop();
      this.seekTo(position);
      this.play();
    }
  }

  /**
   * @returns {Number} The Speed Factor of the Audio
   */
  getSpeedFactor() {
    return this.player.getSpeedFactor();
  }
}
