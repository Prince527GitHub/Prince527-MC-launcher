register('command', () => {
    java.lang.System.gc();
    ChatLib.chat("§8[§6ClearLag§8] §aSuccessfully cleared unused data from memory.");
}).setName("clearlag");