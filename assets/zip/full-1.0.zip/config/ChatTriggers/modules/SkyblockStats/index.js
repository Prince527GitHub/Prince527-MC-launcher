import { 
    Window, UIBlock, UIContainer, UIText,
    AdditiveConstraint, MaxConstraint, ConstantColorConstraint,
    ChildBasedSizeConstraint, SiblingConstraint, RelativeConstraint, CenterConstraint, AspectConstraint,
    Animations
} from 'Elementa/index'
const Color = Java.type('java.awt.Color')

let hasSkyblockAddons = true
const SkyblockAddons = Java.type("codes.biscuit.skyblockaddons.SkyblockAddons")
let renderListener, skillTextField, skillField = null
try {
    renderListener = SkyblockAddons.class.getMethod("getRenderListener").invoke(SkyblockAddons.getInstance())
    skillTextField = renderListener.class.getDeclaredField("skillText")
    skillField = renderListener.class.getDeclaredField("skill")
    skillTextField.setAccessible(true)
    skillField.setAccessible(true)
} catch (error) {
    hasSkyblockAddons = false
}

const fadeOutDelay = 250

function getProgressColor(name) {
    switch(name) {
        case "Mining": return new Color(.4, .44, .45)
        case "Combat": return new Color(.61, .09, .07)
        case "Foraging": return new Color(.27, .12, .02)
        case "Fishing": return new Color(0, .67, .72)
        case "Farming": return new Color(.04, .47, .07)
        case "Carpentry": return new Color(.65, .31, 0)
        case "Enchanting": return new Color(.66, 1, .15)
        case "Alchemy": return new Color(1, .73, .13)
        case "Rune Crafting": return new Color(.61, .22, .81)
        default: return new Color(.4, .6, 0)
    }
}

const window = new Window()

const statsContainer = new UIContainer()
statsContainer.setX((2).pixels(true))
statsContainer.setWidth((150).pixels())
statsContainer.setHeight(new ChildBasedSizeConstraint())
window.addChild(statsContainer)


let stats = []
class Stat {
    constructor(name) {this.ui = new UIBlock(new Color(0, 0, 0, 0))
        this.pinned = false
        this.fadeOutTime = fadeOutDelay

        this.ui.setX((10).pixels())
        this.ui.setY(new AdditiveConstraint(new SiblingConstraint(), (2).pixels()))
        this.ui.setWidth(new RelativeConstraint())
        this.ui.setHeight(new AdditiveConstraint(new ChildBasedSizeConstraint(), (10).pixels()))
        this.ui.onMouseEnter(() => {
            if (Client.isInChat()) {
                this.showOptions()
            }
        })
        this.ui.onMouseLeave(() => {
            this.hideOptions()
        })
        statsContainer.addChild(this.ui)

        this.title = new UIContainer()
        this.title.setY((5).pixels())
        this.title.setWidth(new RelativeConstraint())
        this.title.setHeight((9).pixels())
        this.ui.addChild(this.title)

        this.name = new UIText(name)
        this.name.setX((5).pixels())
        this.title.addChild(this.name)

        this.progressText = new UIContainer()
        this.progressText.setX((5).pixels(true))
        this.progressText.setWidth(new ChildBasedSizeConstraint())
        this.progressText.setHeight((9).pixels())
        this.title.addChild(this.progressText)


        this.total = new UIText("")
        this.progressText.addChild(this.total)

        this.slash = new UIText("/")
        this.slash.setX(new SiblingConstraint())
        this.progressText.addChild(this.slash)

        this.next = new UIText("")
        this.next.setX(new SiblingConstraint())
        this.progressText.addChild(this.next)

        this.pinnedContainer = new UIContainer()
        this.pinnedContainer.setX((5).pixels())
        this.pinnedContainer.setY((12).pixels(true))
        this.pinnedContainer.setWidth(new ChildBasedSizeConstraint())
        this.ui.addChild(this.pinnedContainer)

        this.pinnedBox = new UIBlock(new Color(0, 0, 0, 0))
        this.pinnedBox.setWidth((10).pixels())
        this.pinnedBox.setHeight((10).pixels())
        this.pinnedBox.onMouseClick(() => {
            this.togglePinned()
        })
        this.pinnedContainer.addChild(this.pinnedBox)

        this.pinnedCheck = new UIBlock(new Color(0, 1, 0, 0))
        this.pinnedCheck.setX(new CenterConstraint())
        this.pinnedCheck.setY(new CenterConstraint())
        this.pinnedCheck.setHeight(new AspectConstraint())
        this.pinnedBox.addChild(this.pinnedCheck)
        this.updatePinned()

        this.pinnedText = new UIText("pinned")
        this.pinnedText.setX((12).pixels())
        this.pinnedText.setColor(new ConstantColorConstraint(new Color(1, 1, 1, 0.05)))
        this.pinnedContainer.addChild(this.pinnedText)

        this.progressBar = new UIBlock(new Color(0, 0, 0, 0.5))
        this.progressBar.setX(new CenterConstraint())
        this.progressBar.setY((15).pixels())
        this.progressBar.setWidth(new RelativeConstraint(0.95))
        this.progressBar.setHeight((10).pixels())
        this.ui.addChild(this.progressBar)

        this.progressBarTotal = new UIBlock(getProgressColor(name))
        this.progressBarTotal.setWidth((0).pixels())
        this.progressBarTotal.setHeight(new RelativeConstraint())
        this.progressBar.addChild(this.progressBarTotal)


        this.gainedXPContainer = new UIContainer()
        this.gainedXPContainer.setX(
            new MaxConstraint(
                new AdditiveConstraint(new SiblingConstraint(), (2).pixels()), 
                (0).pixels(true)
            )
        )
        this.gainedXPContainer.setWidth(new ChildBasedSizeConstraint())
        this.progressBar.addChild(this.gainedXPContainer)

        this.gainedXP = new UIText("+")
        this.gainedXP.setX((-5).pixels())
        this.gainedXP.setY((1.5).pixels())
        this.gainedXP.setColor(new ConstantColorConstraint(new Color(1, 1, 1, .05)))
        this.gainedXPContainer.addChild(this.gainedXP)
    }

    togglePinned() {
        this.pinned = !this.pinned
        this.updatePinned()
    }

    updatePinned() {
        if (this.pinned) {
            var animation = this.pinnedCheck.makeAnimation()
            animation.setWidthAnimation(Animations.OUT_EXP, 0.5, (8).pixels())
            animation.begin()
        } else {
            var animation = this.pinnedCheck.makeAnimation()
            animation.setWidthAnimation(Animations.OUT_EXP, 0.5, (0).pixels())
            animation.begin()
        }
    }

    animateIn() {
        var animation = this.ui.makeAnimation()
        animation.setXAnimation(Animations.OUT_EXP, 1, (0).pixels())
        animation.setColorAnimation(Animations.OUT_EXP, 1, new ConstantColorConstraint(new Color(0, 0, 0, 0.25)))
        animation.begin()
    }

    animateOut() {
        var animation = this.ui.makeAnimation()
        animation.setXAnimation(Animations.OUT_EXP, 1, (10).pixels())
        animation.setColorAnimation(Animations.OUT_EXP, 1, new ConstantColorConstraint(new Color(0, 0, 0, 0)))
        animation.onCompleteRunnable(() => {
            stats.splice(stats.indexOf(this), 1)
            statsContainer.removeChild(this.ui)
        })
        animation.begin()

        let texts = [this.name, this.total, this.slash, this.next]
        texts.forEach(text => {
            animation = text.makeAnimation()
            animation.setColorAnimation(Animations.OUT_EXP, 1, new ConstantColorConstraint(new Color(1, 1, 1, 0.05)))
            animation.begin()
        })
        let progress = [this.progressBar, this.progressBarTotal]
        progress.forEach(block => {
            color = block.getColor()
            animation = block.makeAnimation()
            animation.setColorAnimation(Animations.OUT_EXP, 1, new ConstantColorConstraint(new Color(color.r / 255, color.g / 255, color.b / 255, 0)))
            animation.begin()
        })
        
    }

    showOptions() {
        var animation = this.ui.makeAnimation()
        animation.setHeightAnimation(Animations.OUT_EXP, 0.5, new AdditiveConstraint(new ChildBasedSizeConstraint(), (21).pixels()))
        animation.begin()
        animation = this.pinnedText.makeAnimation()
        animation.setColorAnimation(Animations.OUT_EXP, 0.5, new ConstantColorConstraint(new Color(1, 1, 1, 1)))
        animation.begin()
        animation = this.pinnedBox.makeAnimation()
        animation.setColorAnimation(Animations.OUT_EXP, 0.5, new ConstantColorConstraint(new Color(0, 0, 0, 0.5)))
        animation.begin()
        animation = this.pinnedCheck.makeAnimation()
        animation.setColorAnimation(Animations.OUT_EXP, 0.5, new ConstantColorConstraint(new Color(0, 1, 0, 1)))
        animation.begin()
    }

    hideOptions() {
        var animation = this.ui.makeAnimation()
        animation.setHeightAnimation(Animations.OUT_EXP, 0.5, new AdditiveConstraint(new ChildBasedSizeConstraint(), (10).pixels()))
        animation.begin()
        animation = this.pinnedText.makeAnimation()
        animation.setColorAnimation(Animations.OUT_EXP, 0.5, new ConstantColorConstraint(new Color(1, 1, 1, 0.05)))
        animation.begin()
        animation = this.pinnedBox.makeAnimation()
        animation.setColorAnimation(Animations.OUT_EXP, 0.5, new ConstantColorConstraint(new Color(0, 0, 0, 0)))
        animation.begin()
        animation = this.pinnedCheck.makeAnimation()
        animation.setColorAnimation(Animations.OUT_EXP, 0.5, new ConstantColorConstraint(new Color(0, 1, 0, 0)))
        animation.begin()
    }

    update(gained, total, next) {
        this.fadeOutTime = fadeOutDelay
        if (total !== this.total.getText() || next !== this.next.getText()) {
            this.total.setText(total)
            this.next.setText(next)
            this.progressBarTotal.makeAnimation().setWidthAnimation(
                Animations.OUT_EXP, 1,
                new RelativeConstraint(parseNumber(this.total.getText()) / parseNumber(this.next.getText()))
            ).begin()
            if (this.gainedXP.getText() === "+") {
                this.gainedXP.setText("+" + gained)
            } else {
                this.gainedXP.setText("+" + roundTo(parseFloat(this.gainedXP.getText().replace("+", "")) + parseFloat(gained), 2))
            }
            var fadeIn = this.gainedXP.makeAnimation()
            fadeIn.setXAnimation(Animations.OUT_EXP, 1, (0).pixels())
            fadeIn.setColorAnimation(Animations.OUT_EXP, 1, new ConstantColorConstraint(new Color(1, 1, 1, 1)))
            fadeIn.onComplete(() => {
                var fadeOut = this.gainedXP.makeAnimation()
                fadeOut.setXAnimation(Animations.OUT_EXP, 1, (-5).pixels())
                fadeOut.setColorAnimation(Animations.OUT_EXP, 1, new ConstantColorConstraint(new Color(1, 1, 1, 0.05)))
                fadeOut.onComplete(() => {
                    this.gainedXP.setText("+")
                })
                fadeOut.begin()
            })
            fadeIn.begin()
        }
    }

    step() {
        if (this.pinned) return
        if (Client.isInChat()) {
            this.fadeOutTime = fadeOutDelay
            return
        }
        if (this.fadeOutTime === 0) {
            this.animateOut()
            this.fadeOutTime = -1
            return
        }
        this.fadeOutTime--
    }
}


//&c723/723❤     &3+38.5 Fishing (1,152/2,000)     &b177/174✎ Mana&r&r
//&c723/723❤     &3+0.5 Mining (84,246.3/600,000)     &b174/174✎ Mana&r&r
//&c1276/1276❤     &5+&d48 &5Runecrafting (2,948.9/6,250)     &b202/202✎ Mana&r&r
register('actionbar', (gained, name, total, next) => {
    newStat = true
    stats.forEach(stat => {
        if (stat.name.getText() === name) {
            stat.update(gained, total, next)
            newStat = false
        }
    })
    if (newStat) {
        var stat = new Stat(name)
        stat.update(gained, total, next)
        stat.animateIn()
        stats.push(stat)
    }
}).setCriteria('&${*}❤     &3+${gained} ${name} (${total}/${next})     &b${*}✎ Mana&r&r')

register('actionbar', (gained, total, next) => {
    newStat = true
    stats.forEach(stat => {
        if (stat.name.getText() === 'Rune Crafting') {
            stat.update(gained, total, next)
            newStat = false
        }
    })
    if (newStat) {
        var stat = new Stat('Rune Crafting')
        stat.update(gained, total, next)
        stat.animateIn()
        stats.push(stat)
    }
}).setCriteria('&${*}❤     &5+&d${gained} &5Runecrafting (${total}/${next})     &b${*}✎ Mana&r&r')

// actionbar trigger for SBA
if (hasSkyblockAddons) {
    register('actionbar', () => {
        if (skillTextField.get(renderListener) === null) return
        
        let name = skillField.get(renderListener)?.toString()
        if (name === "RUNECRAFTING") name = "Rune Crafting"
        else name = name.charAt(0) + name.slice(1).toLowerCase()

        const skillText = skillTextField.get(renderListener).toString()
        const gained = skillText.split("+")[1].split(" (")[0]
        const xp = skillText.split(" (")[1].split(")")[0]
        const total = xp.split("/")[0]
        const next = xp.split("/")[1]
    
        newStat = true
        stats.forEach(stat => {
            if (stat.name.getText() === name) {
                stat.update(gained, total, next)
                newStat = false
            }
        })
        if (newStat) {
            var stat = new Stat(name)
            stat.update(gained, total, next)
            stat.animateIn()
            stats.push(stat)
        }
    })
}

register('tick', () => {
    stats.forEach(stat => {
        stat.step()
    })
})

register('renderOverlay', () => {
    window.draw()
})

register('clicked', (mouseX, mouseY, button, state) => {
    if (!state) return
    window.mouseClick(mouseX, mouseY, button)
})

function parseNumber(number) {
    return number.replace(/,|\..*/g, "")
}

function roundTo(n, digits) {
    var negative = false;
    if (digits === undefined) {
        digits = 0;
    }
        if( n < 0) {
        negative = true;
      n = n * -1;
    }
    var multiplicator = Math.pow(10, digits);
    n = parseFloat((n * multiplicator).toFixed(11));
    n = (Math.round(n) / multiplicator).toFixed(2);
    if( negative ) {    
        n = (n * -1).toFixed(2);
    }
    return n;
}

// debug
register('command', () => {
    let statsList = ["Mining", "Combat", "Foraging", "Fishing", "Farming", "Carpentry", "Enchanting", "Alchemy", "Rune Crafting"]
    statsList.forEach((stat) => {
        let exampleStat = new Stat(stat)
        exampleStat.update("25", "1,234.5", "2,345")
        exampleStat.animateIn()
        stats.push(exampleStat)
    })
}).setName('statsTest')
